import { c as create_ssr_component, a as compute_rest_props, g as getContext, b as spread, e as escape_attribute_value, d as escape_object, f as escape, v as validate_component } from "../../../chunks/ssr.js";
const ArrowRight = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["weight", "color", "size", "mirrored"]);
  const { weight: ctxWeight, color: ctxColor, size: ctxSize, mirrored: ctxMirrored, ...restCtx } = getContext("iconCtx") || {};
  let { weight = ctxWeight ?? "regular" } = $$props;
  let { color = ctxColor ?? "currentColor" } = $$props;
  let { size = ctxSize ?? "1em" } = $$props;
  let { mirrored = ctxMirrored || false } = $$props;
  if ($$props.weight === void 0 && $$bindings.weight && weight !== void 0)
    $$bindings.weight(weight);
  if ($$props.color === void 0 && $$bindings.color && color !== void 0)
    $$bindings.color(color);
  if ($$props.size === void 0 && $$bindings.size && size !== void 0)
    $$bindings.size(size);
  if ($$props.mirrored === void 0 && $$bindings.mirrored && mirrored !== void 0)
    $$bindings.mirrored(mirrored);
  return `  <svg${spread(
    [
      { xmlns: "http://www.w3.org/2000/svg" },
      { width: escape_attribute_value(size) },
      { height: escape_attribute_value(size) },
      { fill: escape_attribute_value(color) },
      {
        transform: escape_attribute_value(mirrored ? "scale(-1, 1)" : void 0)
      },
      { viewBox: "0 0 256 256" },
      escape_object(restCtx),
      escape_object($$restProps)
    ],
    {}
  )}>${slots.default ? slots.default({}) : ``}<rect width="256" height="256" fill="none"></rect>${weight === "bold" ? `<path d="M224.49,136.49l-72,72a12,12,0,0,1-17-17L187,140H40a12,12,0,0,1,0-24H187L135.51,64.48a12,12,0,0,1,17-17l72,72A12,12,0,0,1,224.49,136.49Z"></path>` : `${weight === "duotone" ? `<path d="M216,128l-72,72V56Z" opacity="0.2"></path><path d="M221.66,122.34l-72-72A8,8,0,0,0,136,56v64H40a8,8,0,0,0,0,16h96v64a8,8,0,0,0,13.66,5.66l72-72A8,8,0,0,0,221.66,122.34ZM152,180.69V75.31L204.69,128Z"></path>` : `${weight === "fill" ? `<path d="M221.66,133.66l-72,72A8,8,0,0,1,136,200V136H40a8,8,0,0,1,0-16h96V56a8,8,0,0,1,13.66-5.66l72,72A8,8,0,0,1,221.66,133.66Z"></path>` : `${weight === "light" ? `<path d="M220.24,132.24l-72,72a6,6,0,0,1-8.48-8.48L201.51,134H40a6,6,0,0,1,0-12H201.51L139.76,60.24a6,6,0,0,1,8.48-8.48l72,72A6,6,0,0,1,220.24,132.24Z"></path>` : `${weight === "regular" ? `<path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>` : `${weight === "thin" ? `<path d="M218.83,130.83l-72,72a4,4,0,0,1-5.66-5.66L206.34,132H40a4,4,0,0,1,0-8H206.34L141.17,58.83a4,4,0,0,1,5.66-5.66l72,72A4,4,0,0,1,218.83,130.83Z"></path>` : `${escape((console.error('Unsupported icon weight. Choose from "thin", "light", "regular", "bold", "fill", or "duotone".'), ""))}`}`}`}`}`}`}</svg>`;
});
const css = {
  code: "h1.svelte-1pbku25{width:-moz-fit-content;width:fit-content;font-size:4.5rem;line-height:1;font-weight:700;@supports (background: -webkit-linear-gradient(180deg, #fff, #000)) {\n			color: transparent;\n			background: -webkit-linear-gradient(\n				0deg,\n				#FF7A00,\n				#FFC700\n			);\n			-webkit-fill-color: transparent;\n			-webkit-background-clip: text;\n		}}",
  map: '{"version":3,"file":"+page.svelte","sources":["+page.svelte"],"sourcesContent":["<script>\\n\\timport { ArrowRight } from \\"phosphor-svelte\\";\\n<\/script>\\n\\n<main\\n\\tclass=\\"flex-1 w-[calc(100%_-_24px)] max-w-screen-main mx-auto flex flex-col items-center justify-center\\"\\n>\\n\\t<h1 class=\\"mb-20 text-center\\">Kaio Felipe</h1>\\n\\n\\t<h2 class=\\"mb-6 font-medium text-2xl text-center\\">Desenvolvo layouts e sites fantásticos!</h2>\\n\\n\\t<a class=\\"group btn text-lg font-semibold\\" href=\\"/projetos\\">\\n\\t\\t<span class=\\"max-2xs:hidden\\">Conheça o meu trabalho</span>\\n\\t\\t<span class=\\"2xs:hidden\\">Projetos</span>\\n\\t\\t<ArrowRight\\n\\t\\t\\tsize=\\"20\\"\\n\\t\\t\\tweight=\\"bold\\"\\n\\t\\t\\tclass=\\"translate-x-0 group-hover:translate-x-1 transition-all duration-150 ease-in\\"\\n\\t\\t/>\\n\\t</a>\\n</main>\\n\\n<style>\\n\\th1 {\\n\\t\\twidth: -moz-fit-content;\\n\\t\\twidth: fit-content;\\n\\t\\tfont-size: 4.5rem;\\n\\t\\tline-height: 1;\\n\\t\\tfont-weight: 700;\\n\\n\\t\\t@supports (background: -webkit-linear-gradient(180deg, #fff, #000)) {\\n\\t\\t\\tcolor: transparent;\\n\\t\\t\\tbackground: -webkit-linear-gradient(\\n\\t\\t\\t\\t0deg,\\n\\t\\t\\t\\t#FF7A00,\\n\\t\\t\\t\\t#FFC700\\n\\t\\t\\t);\\n\\t\\t\\t-webkit-fill-color: transparent;\\n\\t\\t\\t-webkit-background-clip: text;\\n\\t\\t}\\n}\\n</style>\\n"],"names":[],"mappings":"AAuBC,iBAAG,CACF,KAAK,CAAE,gBAAgB,CACvB,KAAK,CAAE,WAAW,CAClB,SAAS,CAAE,MAAM,CACjB,WAAW,CAAE,CAAC,CACd,WAAW,CAAE,GAAG,CAEhB,UAAU,CAAC,YAAY,wBAAwB,MAAM,CAAC,CAAC,IAAI,CAAC,CAAC,IAAI,CAAC,CAAC,CAAC;AACtE,GAAG,OAAO,WAAW;AACrB,GAAG,YAAY;AACf,IAAI,IAAI,CAAC;AACT,IAAI,OAAO,CAAC;AACZ,IAAI,OAAO;AACX,IAAI;AACJ,GAAG,oBAAoB,WAAW;AAClC,GAAG,yBAAyB,IAAI;AAChC,GACA"}'
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<main class="flex-1 w-[calc(100%_-_24px)] max-w-screen-main mx-auto flex flex-col items-center justify-center"><h1 class="mb-20 text-center svelte-1pbku25" data-svelte-h="svelte-kb93l5">Kaio Felipe</h1> <h2 class="mb-6 font-medium text-2xl text-center" data-svelte-h="svelte-i6htgq">Desenvolvo layouts e sites fantásticos!</h2> <a class="group btn text-lg font-semibold" href="/projetos"><span class="max-2xs:hidden" data-svelte-h="svelte-1avbywz">Conheça o meu trabalho</span> <span class="2xs:hidden" data-svelte-h="svelte-1iobnpo">Projetos</span> ${validate_component(ArrowRight, "ArrowRight").$$render(
    $$result,
    {
      size: "20",
      weight: "bold",
      class: "translate-x-0 group-hover:translate-x-1 transition-all duration-150 ease-in"
    },
    {},
    {}
  )}</a> </main>`;
});
export {
  Page as default
};
