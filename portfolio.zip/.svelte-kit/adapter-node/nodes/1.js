

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.CaE3TzPs.js","_app/immutable/chunks/scheduler.B0hamzgI.js","_app/immutable/chunks/index.BpcC8uAT.js","_app/immutable/chunks/stores.BMXrdwY3.js","_app/immutable/chunks/entry.CRqSOa9k.js"];
export const stylesheets = [];
export const fonts = [];
