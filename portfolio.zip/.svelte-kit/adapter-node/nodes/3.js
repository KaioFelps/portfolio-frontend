

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(public)/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.Cb2io_Am.js","_app/immutable/chunks/scheduler.B0hamzgI.js","_app/immutable/chunks/index.BpcC8uAT.js","_app/immutable/chunks/spread.CN4WR7uZ.js"];
export const stylesheets = ["_app/immutable/assets/3.v8hbnfbB.css"];
export const fonts = [];
