import{a as t}from"../chunks/entry.CRqSOa9k.js";export{t as start};
